
//necessary imports
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import java.awt.SystemColor;
import javax.swing.JButton;

import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.time.Year;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JScrollPane;

public class Enrollment extends JFrame {

	// needed variables
	// main panel
	private JPanel contentPane;
	// label with school image
	private JLabel schoolImage;
	// application panel
	private JPanel applicationPanel;
	// label with title image
	private JLabel applicationLabel;
	// panel with the inputs
	private JPanel inputPanel;
	// name label and textfield
	private JLabel nameLabel;
	private JTextField nameField;
	// birthdate label and field
	private JLabel birthDateLabel;
	private JTextField birthDateField;
	// email label and field
	private JLabel emailLabel;
	private JTextField emailField;
	// phone number label and field
	private JLabel phoneNumberLabel;
	private JTextField phoneNumberField;
	// degree label and field
	private JLabel degreeLabel;
	private JTextField degreeField;
	// major label and combobox
	private JLabel majorLabel;
	private JComboBox majorBox;
	// university label and field
	private JLabel universityLabel;
	private JTextField universityField;
	// GPA label and field
	private JLabel GPALabel;
	private JTextField GPAField;
	// address label and field
	private JLabel addressLabel;
	private JTextField addressField;
	// statement label and text field
	private JLabel statementLabel;
	private JTextArea statementArea;
	private JButton btnSubmit;
	// errorMessage string variable that stores the entire error message
	private String errorMessage = "";
	// counts the number of errors
	private int errorCounter = 0;
	// temporary string storing for checking
	private String temp;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Enrollment frame = new Enrollment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Enrollment() {
		setTitle("SKKU New Students Enrollment");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 741, 594);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		schoolImage = new JLabel("");
		schoolImage.setIcon(new ImageIcon(getClass().getResource("skku_wallpaper.png")));
		contentPane.add(schoolImage, BorderLayout.EAST);

		applicationPanel = new JPanel();
		applicationPanel.setBackground(new Color(255, 255, 255));
		contentPane.add(applicationPanel, BorderLayout.CENTER);
		applicationPanel.setLayout(new BorderLayout(0, 0));

		applicationLabel = new JLabel();
		applicationLabel.setIcon(new ImageIcon(getClass().getResource("title_label.png")));
		applicationPanel.add(applicationLabel, BorderLayout.NORTH);

		inputPanel = new JPanel();
		inputPanel.setBackground(new Color(255, 255, 255));
		applicationPanel.add(inputPanel, BorderLayout.CENTER);
		GridBagLayout gbl_inputPanel = new GridBagLayout();
		gbl_inputPanel.columnWidths = new int[] { 177, -11, 127, 106, 0, 0, 30 };
		gbl_inputPanel.rowHeights = new int[] { 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 72, 0, 0 };
		gbl_inputPanel.columnWeights = new double[] { 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_inputPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
				Double.MIN_VALUE };
		inputPanel.setLayout(gbl_inputPanel);

		nameLabel = new JLabel("Applicant Name:");
		nameLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_applicantLabel = new GridBagConstraints();
		gbc_applicantLabel.anchor = GridBagConstraints.EAST;
		gbc_applicantLabel.insets = new Insets(0, 0, 5, 5);
		gbc_applicantLabel.gridx = 0;
		gbc_applicantLabel.gridy = 1;
		inputPanel.add(nameLabel, gbc_applicantLabel);

		nameField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		nameField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				nameField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_nameField = new GridBagConstraints();
		gbc_nameField.gridwidth = 3;
		gbc_nameField.insets = new Insets(0, 0, 5, 5);
		gbc_nameField.fill = GridBagConstraints.HORIZONTAL;
		gbc_nameField.gridx = 1;
		gbc_nameField.gridy = 1;
		inputPanel.add(nameField, gbc_nameField);
		nameField.setColumns(10);

		birthDateLabel = new JLabel("Birth Date:");
		GridBagConstraints gbc_birthDateLabel = new GridBagConstraints();
		gbc_birthDateLabel.anchor = GridBagConstraints.EAST;
		gbc_birthDateLabel.insets = new Insets(0, 0, 5, 5);
		gbc_birthDateLabel.gridx = 0;
		gbc_birthDateLabel.gridy = 2;
		inputPanel.add(birthDateLabel, gbc_birthDateLabel);

		birthDateField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		birthDateField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				birthDateField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 3;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 2;
		inputPanel.add(birthDateField, gbc_textField);
		birthDateField.setColumns(10);

		phoneNumberLabel = new JLabel("Phone Number:");
		GridBagConstraints gbc_phoneNumberLabel = new GridBagConstraints();
		gbc_phoneNumberLabel.anchor = GridBagConstraints.EAST;
		gbc_phoneNumberLabel.insets = new Insets(0, 0, 5, 5);
		gbc_phoneNumberLabel.gridx = 0;
		gbc_phoneNumberLabel.gridy = 3;
		inputPanel.add(phoneNumberLabel, gbc_phoneNumberLabel);

		phoneNumberField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		phoneNumberField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				phoneNumberField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_phoneNumberField = new GridBagConstraints();
		gbc_phoneNumberField.gridwidth = 3;
		gbc_phoneNumberField.insets = new Insets(0, 0, 5, 5);
		gbc_phoneNumberField.fill = GridBagConstraints.HORIZONTAL;
		gbc_phoneNumberField.gridx = 1;
		gbc_phoneNumberField.gridy = 3;
		inputPanel.add(phoneNumberField, gbc_phoneNumberField);
		phoneNumberField.setColumns(10);

		emailLabel = new JLabel("Email:");
		GridBagConstraints gbc_emailLabel = new GridBagConstraints();
		gbc_emailLabel.anchor = GridBagConstraints.EAST;
		gbc_emailLabel.insets = new Insets(0, 0, 5, 5);
		gbc_emailLabel.gridx = 0;
		gbc_emailLabel.gridy = 4;
		inputPanel.add(emailLabel, gbc_emailLabel);

		emailField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		emailField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				emailField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_emailField = new GridBagConstraints();
		gbc_emailField.gridwidth = 3;
		gbc_emailField.insets = new Insets(0, 0, 5, 5);
		gbc_emailField.fill = GridBagConstraints.HORIZONTAL;
		gbc_emailField.gridx = 1;
		gbc_emailField.gridy = 4;
		inputPanel.add(emailField, gbc_emailField);
		emailField.setColumns(10);

		degreeLabel = new JLabel("Degree:");
		GridBagConstraints gbc_degreeLabel = new GridBagConstraints();
		gbc_degreeLabel.anchor = GridBagConstraints.EAST;
		gbc_degreeLabel.insets = new Insets(0, 0, 5, 5);
		gbc_degreeLabel.gridx = 0;
		gbc_degreeLabel.gridy = 5;
		inputPanel.add(degreeLabel, gbc_degreeLabel);

		degreeField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		degreeField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				degreeField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_degreeField = new GridBagConstraints();
		gbc_degreeField.gridwidth = 3;
		gbc_degreeField.insets = new Insets(0, 0, 5, 5);
		gbc_degreeField.fill = GridBagConstraints.HORIZONTAL;
		gbc_degreeField.gridx = 1;
		gbc_degreeField.gridy = 5;
		inputPanel.add(degreeField, gbc_degreeField);
		degreeField.setColumns(10);

		majorLabel = new JLabel("Major:");
		GridBagConstraints gbc_majorLabel = new GridBagConstraints();
		gbc_majorLabel.anchor = GridBagConstraints.EAST;
		gbc_majorLabel.insets = new Insets(0, 0, 5, 5);
		gbc_majorLabel.gridx = 0;
		gbc_majorLabel.gridy = 6;
		inputPanel.add(majorLabel, gbc_majorLabel);

		majorBox = new JComboBox();
		majorBox.setModel(new DefaultComboBoxModel(new String[] { "", "HUMSS", "STEM", "ABM", "GAS" }));
		GridBagConstraints gbc_majorBox = new GridBagConstraints();
		gbc_majorBox.gridwidth = 3;
		gbc_majorBox.insets = new Insets(0, 0, 5, 5);
		gbc_majorBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_majorBox.gridx = 1;
		gbc_majorBox.gridy = 6;
		inputPanel.add(majorBox, gbc_majorBox);

		universityLabel = new JLabel("University (for Graduates):");
		GridBagConstraints gbc_universityLabel = new GridBagConstraints();
		gbc_universityLabel.anchor = GridBagConstraints.EAST;
		gbc_universityLabel.insets = new Insets(0, 0, 5, 5);
		gbc_universityLabel.gridx = 0;
		gbc_universityLabel.gridy = 7;
		inputPanel.add(universityLabel, gbc_universityLabel);

		universityField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		universityField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				universityField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_universityField = new GridBagConstraints();
		gbc_universityField.gridwidth = 3;
		gbc_universityField.insets = new Insets(0, 0, 5, 5);
		gbc_universityField.fill = GridBagConstraints.HORIZONTAL;
		gbc_universityField.gridx = 1;
		gbc_universityField.gridy = 7;
		inputPanel.add(universityField, gbc_universityField);
		universityField.setColumns(10);

		GPALabel = new JLabel("GPA (for Graduates):");
		GridBagConstraints gbc_GPALabel = new GridBagConstraints();
		gbc_GPALabel.anchor = GridBagConstraints.EAST;
		gbc_GPALabel.insets = new Insets(0, 0, 5, 5);
		gbc_GPALabel.gridx = 0;
		gbc_GPALabel.gridy = 8;
		inputPanel.add(GPALabel, gbc_GPALabel);

		GPAField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		GPAField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				GPAField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_GPAField = new GridBagConstraints();
		gbc_GPAField.gridwidth = 3;
		gbc_GPAField.insets = new Insets(0, 0, 5, 5);
		gbc_GPAField.fill = GridBagConstraints.HORIZONTAL;
		gbc_GPAField.gridx = 1;
		gbc_GPAField.gridy = 8;
		inputPanel.add(GPAField, gbc_GPAField);
		GPAField.setColumns(10);

		addressLabel = new JLabel("Home Address:");
		GridBagConstraints gbc_addressLabel = new GridBagConstraints();
		gbc_addressLabel.anchor = GridBagConstraints.EAST;
		gbc_addressLabel.insets = new Insets(0, 0, 5, 5);
		gbc_addressLabel.gridx = 0;
		gbc_addressLabel.gridy = 9;
		inputPanel.add(addressLabel, gbc_addressLabel);

		addressField = new JTextField();
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		addressField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				addressField.setForeground(Color.BLACK);
			}
		});
		GridBagConstraints gbc_addressField = new GridBagConstraints();
		gbc_addressField.gridwidth = 3;
		gbc_addressField.insets = new Insets(0, 0, 5, 5);
		gbc_addressField.fill = GridBagConstraints.HORIZONTAL;
		gbc_addressField.gridx = 1;
		gbc_addressField.gridy = 9;
		inputPanel.add(addressField, gbc_addressField);
		addressField.setColumns(10);

		statementLabel = new JLabel("Personal Statement:");
		GridBagConstraints gbc_statementLabel = new GridBagConstraints();
		gbc_statementLabel.anchor = GridBagConstraints.EAST;
		gbc_statementLabel.insets = new Insets(0, 0, 5, 5);
		gbc_statementLabel.gridx = 0;
		gbc_statementLabel.gridy = 10;
		inputPanel.add(statementLabel, gbc_statementLabel);

		// scroll pane for statement Area
		scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 2;
		gbc_scrollPane.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 2;
		gbc_scrollPane.gridy = 10;
		inputPanel.add(scrollPane, gbc_scrollPane);

		statementArea = new JTextArea();
		scrollPane.setViewportView(statementArea);
		// when clicking inside the text field, change color to black (in case there was
		// an error)
		statementArea.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				statementArea.setForeground(Color.BLACK);
			}
		});
		statementArea.setBackground(SystemColor.inactiveCaptionBorder);

		btnSubmit = new JButton("Submit Application");
		btnSubmit.addActionListener(new ActionListener() {
			// once submit button is clicked, try catch all the fields
			public void actionPerformed(ActionEvent action) {
				// try catch name
				try {
					// store name field into temp
					temp = nameField.getText();
					// check name
					// if name field is empty
					if (temp.length() == 0) {
						throw new Exception("Empty");
					}
					// if name does not contain space, throw exception
					else if (!temp.contains(" ")) {
						throw new Exception("Only one");
					}
					// if name has number in it, throw exception
					for (int i = 0; i < temp.length(); i++) {
						if (Character.isDigit(temp.charAt(i))) {
							throw new Exception("Number");
						}
					}
				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your name\n";
					} else if (e.getMessage() == "Only one") {
						errorMessage += errorCounter + ". You forgot to write your name or surname\n";
					} else {
						errorMessage += errorCounter + ". You cannot use numbers here\n";
					}
					// set field foreground to red
					nameField.setForeground(Color.RED);
				}

				// try catch date
				try {
					// store date field into temp
					temp = birthDateField.getText();
					// if there is extra or lacking characters from mm/dd/yyyy
					// throw format exception
					if (temp.length() == 0) {
						throw new Exception("Empty");
					}
					if (temp.length() != 10) {
						throw new Exception("Format");
					} else if (temp.charAt(2) != '/' || temp.charAt(5) != '/') {
						throw new Exception("Format");
					}

					// check if everything is a number
					for (int i = 0; i < temp.length(); i++) {
						// ignore the '/' characters
						if (i == 2 || i == 5) {
							i++;
						}

						if (!Character.isDigit(temp.charAt(i))) {
							throw new Exception("NaN");
						}
					}

					// then if the previous all previous tests have succeeded, check the date
					// create 3 int variables from substrings for month, day and year
					int month = Integer.parseInt(temp.substring(0, 2));
					int day = Integer.parseInt(temp.substring(3, 5));
					int year = Integer.parseInt(temp.substring(6));
					int currentYear = Year.now().getValue();
					// if month does not exist
					if (month > 12 || month < 1) {
						throw new Exception("Undefined");
					}
					// if day does not exist
					else if (day > 31 || day < 1) {
						throw new Exception("Undefined");
					}
					// if year does not exist
					else if (year > currentYear) {
						throw new Exception("Future");
					}
					// if age is not above 18
					// for this program, max age for application will be 40
					else if (currentYear - year < 18 || currentYear - year > 40) {
						throw new Exception("Old or Young");
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your birth date\n";
					} else if (e.getMessage() == "Format") {
						errorMessage += errorCounter + ". Birth date must be in 'mm/dd/yyyy' format\n";
					} else if (e.getMessage() == "NaN") {
						errorMessage += errorCounter + ". Character detected. Input integers only\n";
					} else if (e.getMessage() == "Undefined") {
						errorMessage += errorCounter + ". Month or Day does not exist. Please input again\n";
					} else if (e.getMessage() == "Future") {
						errorMessage += errorCounter + ". This year has not happened yet. Are you from the future?\n";
					} else if (e.getMessage() == "Old or Young") {
						errorMessage += errorCounter + ". You must be of age between 18 - 40 to be able to apply.\n";
					}
					// set field foreground to red
					birthDateField.setForeground(Color.RED);
				}

				// try catch Phone number
				try {
					// store phone number field into temp
					temp = phoneNumberField.getText();
					// if there is extra or lacking characters from 012-3456-7890
					// throw format exception
					if (temp.length() == 0) {
						throw new Exception("Empty");
					} else if (temp.length() != 13) {
						throw new Exception("Format");
					} else if (temp.charAt(3) != '-' || temp.charAt(8) != '-') {
						throw new Exception("Format");
					}

					// check if everything is a number
					for (int i = 0; i < temp.length(); i++) {
						// ignore the '-' characters
						if (i == 3 || i == 8) {
							i++;
						}

						if (!Character.isDigit(temp.charAt(i))) {
							throw new Exception("NaN");
						}
					}

					// check if the 3 digit code is correct (010)
					int firstDigits = Integer.parseInt(temp.substring(0, 3));
					if (firstDigits != 10) {
						throw new Exception("Format");
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your phone number\n";
					} else if (e.getMessage() == "Format") {
						errorMessage += errorCounter + ". Proper format for a phone number is '010-1234-5678'\n";
					} else if (e.getMessage() == "NaN") {
						errorMessage += errorCounter + ". Character detected. Input integers only\n";
					}
					// set field foreground to red
					phoneNumberField.setForeground(Color.RED);
				}

				// try catch for email
				try {
					// store email field in temp
					temp = emailField.getText();

					// nothing inputted
					if (temp.length() == 0) {
						throw new Exception("Empty");
					}

					// if @ character is not found
					if (!temp.contains("@")) {
						throw new Exception("Format");
					}
					//if @ character is the first character
					else if(temp.indexOf("@") == 0) {
						throw new Exception("Format");
					}
					
					// position right after the @ character
					int afterAtPosition = temp.indexOf("@") + 1;
					// create substring after the at position to check the some.some format
					String format = temp.substring(afterAtPosition);

					// if the substring does not contain a "." or does not have the right format
					// will not consider the .com, .edu, since there may be several different
					// endings
					if (!format.contains(".")) {
						throw new Exception("Format");
					} else if (format.indexOf(".") == 0) {
						throw new Exception("Format");
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your email\n";
					} else if (e.getMessage() == "Format") {
						errorMessage += errorCounter + ". Email must be in example@some.some format\n";
					}
					// set field foreground to red
					emailField.setForeground(Color.RED);
				}

				// try catch for degree (Bachelor or PhD only)
				try {
					// store degree field into temp
					temp = degreeField.getText();

					// if degree field was empty
					if (temp.length() == 0) {
						throw new Exception("Empty");
					}
					// if degree is not Bachelor or PhD
					else if (!temp.contains("Bachelor") && !temp.contains("PhD")) {
						throw new Exception("Invalid");
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your degree\n";
					} else if (e.getMessage() == "Invalid") {
						errorMessage += errorCounter + ". Invalid. Degree can either be Bachelor or PhD\n";
					}
					// set field foreground to red
					degreeField.setForeground(Color.RED);
				}

				// try catch major
				// since it is combo box, only check if empty
				try {
					// if combo box value is empty
					if (majorBox.getSelectedItem().toString() == "") {
						throw new Exception();
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					errorMessage += errorCounter + ". You have to choose a major\n";
				}

				// try catch university
				try {
					// store university field to temp
					temp = universityField.getText();

					// store degree in degree variable
					String degree = degreeField.getText();

					// if empty
					if (temp.length() == 0) {
						// if degree is phd, throw exception
						if (degree.contains("PhD")) {
							throw new Exception("Empty");
						}
					} else {
						// university field is filled but degree == "Bachelor"
						if (degree.contains("Bachelor")) {
							throw new Exception("Bachelor");
						}
					}

					if (degree.contains("PhD")) {
						// if university name does not exist
						if (!temp.contains("University") && !temp.contains("College") && !temp.contains("Institute")) {
							throw new Exception("Invalid University");
						}
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". For graduates, you have to enter university and GPA\n";
					} else if (e.getMessage() == "Bachelor") {
						errorMessage += errorCounter + ". For bachelors, leave these fields empty\n";
					} else if (e.getMessage() == "Invalid University") {
						errorMessage += errorCounter
								+ ". University name must end with either University, College, or Institute\n";
					}
					// set field foreground to red
					universityField.setForeground(Color.RED);
				}

				// try catch GPA
				try {
					// store gpa field into temp first
					temp = GPAField.getText();

					// store degree in degree variable
					String degree = degreeField.getText();

					// if empty
					if (temp.length() == 0) {
						// but degree is phd, throw exception
						if (degree.contains("PhD")) {
							throw new Exception("Empty");
						}
					} else {
						// GPA field is filled but degree == "Bachelor"
						if (degree.contains("Bachelor")) {
							throw new Exception("Bachelor");
						}
					}

					if (degree.contains("PhD")) {
						// check if input is all numerical except for '.'
						for (int i = 0; i < temp.length(); i++) {
							// check using !isDigit
							if (!Character.isDigit(temp.charAt(i))) {
								// if char that got caught was a '.', ignore
								if (temp.charAt(i) != '.') {
									throw new Exception("Input");
								}
							}
						}

						// parse out the GPA to a double
						double GPA = Double.parseDouble(temp);

						// if GPA out of range,
						if (GPA > 4.5 || GPA < 0) {
							// throw exception
							throw new Exception("OutOfRange");
						}
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". For graduates, you have to enter university and GPA\n";
					} else if (e.getMessage() == "Bachelor") {
						errorMessage += errorCounter + ". For bachelors, leave these fields empty\n";
					} else if (e.getMessage() == "Input") {
						errorMessage += errorCounter + ". You cannot input characters in this field\n";
					} else if (e.getMessage() == "OutOfRange") {
						errorMessage += errorCounter + ". GPA must be between 0 and 4.5\n";
					}
					// set field foreground to red
					GPAField.setForeground(Color.RED);
				}

				// try catch home address
				try {
					// for home address, will focus on number input at the start and the format
					temp = addressField.getText();

					// if empty
					if (temp.length() == 0) {
						throw new Exception("Empty");
					}

					// replace all character that are not a comma (,) into "", this will leave the
					// commas only
					// then get the length of the resulting string to get the number of commas in
					// home address
					int formatCount = temp.replaceAll("[^,]", "").length();

					// if formatCount is not 3
					if (formatCount != 3) {
						throw new Exception("Format");
					}

					// position of first comma
					int commaPosition = temp.indexOf(",");

					// create substring for the number portion
					String numberAddress = temp.substring(0, commaPosition);

					// check if all characters in this substring are digits
					for (int i = 0; i < numberAddress.length(); i++) {
						if (!Character.isDigit(numberAddress.charAt(i))) {
							throw new Exception("Format");
						}

					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your home address\n";
					} else if (e.getMessage() == "Format") {
						errorMessage += errorCounter
								+ ". Your address must be in 'number, street, district, city' format\n";
					}

					// set field foreground to red
					addressField.setForeground(Color.RED);
				}

				// try catch personal statement
				try {
					// store statement area into temp
					temp = statementArea.getText();

					// if empty, throw error
					if (temp.length() == 0) {
						throw new Exception("Empty");
					}

					// use a string array to split the words
					// words are split with a space, so use it as advantage
					String[] words = temp.split(" ");

					// if words array length is less than 100, throw error
					if (words.length < 100) {
						throw new Exception("Lacking");
					}

				} catch (Exception e) {
					// increase error count and append error message
					errorCounter++;
					// error message changes depending on error
					if (e.getMessage() == "Empty") {
						errorMessage += errorCounter + ". You have to fill in your Personal Statement\n";
					} else if (e.getMessage() == "Format") {
						errorMessage += errorCounter + ". Your Personal Statement must be at least 100 words\n";
					}

					// set field foreground to red
					statementArea.setForeground(Color.RED);
				}
				// if errorCounter == 0, then print success
				if (errorCounter == 0) {
					// initialize all the text fields
					nameField.setText("");
					birthDateField.setText("");
					phoneNumberField.setText("");
					emailField.setText("");
					degreeField.setText("");
					majorBox.setSelectedItem("");
					universityField.setText("");
					GPAField.setText("");
					addressField.setText("");
					statementArea.setText("");

					// reinitialize values
					errorCounter = 0;
					errorMessage = "";

					JOptionPane.showMessageDialog(Enrollment.this, "Successfully Submitted", "Success Message",
							JOptionPane.INFORMATION_MESSAGE);
				}
				// else, print error message
				else {
					JOptionPane.showMessageDialog(Enrollment.this, errorMessage, "You have the following problems:",
							JOptionPane.ERROR_MESSAGE);

					// initialize values
					errorCounter = 0;
					errorMessage = "";
				}
			}
		});
		btnSubmit.setForeground(UIManager.getColor("ToolBar.highlight"));
		btnSubmit.setBackground(new Color(0, 0, 160));
		GridBagConstraints gbc_btnSubmit = new GridBagConstraints();
		gbc_btnSubmit.anchor = GridBagConstraints.EAST;
		gbc_btnSubmit.gridwidth = 3;
		gbc_btnSubmit.insets = new Insets(0, 0, 0, 5);
		gbc_btnSubmit.gridx = 1;
		gbc_btnSubmit.gridy = 12;
		inputPanel.add(btnSubmit, gbc_btnSubmit);
	}

}
