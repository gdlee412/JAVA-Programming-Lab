
public class Shape3D {
	// initialize field
	// volume of 3d shapes
	private double volume;

	// no constructor since only volume is available in this super class

	// getter and setter methods
	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	// to calculate volume
	public double calculateVolume() {
		return 0;
	}

}
